//
//  ViewController.swift
//  Video Play
//
//  Created by MAC on 17/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit
import  AVKit
import AVFoundation
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
   /* override func viewDidAppear(_ animated: Bool) {
        let videoURL = URL(string: "https://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4")
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }*/

    @IBAction func ClickToPlay(_ sender: Any) {
//         let url = URL(string: "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4")
//        let url = NSURL.init(fileURLWithPath: "MyFileSaveName.mp4")
//        let url = AVPlayer(url: URL(fileURLWithPath: Bundle.main.path(forResource: "MyFileSaveName", ofType: "mp4")!))
//        let urlpath     = Bundle.main.path(forResource: "MyFileSaveName", ofType: "mp4")
//        let fileUrl = NSURL(fileURLWithPath:  Bundle.main.path(forResource: "big_buck_bunny", ofType: "mp4")!)
//           let fileURL         = NSURL.fileURL(withPath: urlpath!)
//        guard let filePath = Bundle.main.path(forResource: "MyFileSaveName", ofType: "mp4") else { return}
//        let player = AVPlayer(url: URL(fileURLWithPath: url))
      /*  let player = AVPlayer(url: url as URL)
               var playerController = AVPlayerViewController()
               playerController.player = player
               playerController.allowsPictureInPicturePlayback = true
               playerController.player?.play()
               self.present(playerController, animated: true, completion: nil)*/
        let videoURL = URL(string: "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4")
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
            
        }
    }
}

